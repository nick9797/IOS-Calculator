//
//  Brain.swift
//  CalculatorMVC
//
//  Created by NICHOLAS SENA on 3/4/19.
//  Copyright © 2019 NICHOLAS SENA. All rights reserved.
//

import Foundation


class Brain{
    
    var display:String
    var num1: Double = 0.0
    var num2: Double = 0.0
    var num3: Double = 0.0
    var op: String = ""
    var firstNum: Bool = true
    var sum: Bool = false
    var minus: Bool = false
    var mul: Bool = false
    var div: Bool = false
    var finished: Bool = false
    
    struct Stack {
        
        fileprivate var array: [String] = []
        
        mutating func push(_ element: String) {
            array.append(element)
        }
        
        mutating func pop() -> String? {
            return array.popLast()
        }
        
        func peek() -> String? {
            return array.last
        }
    }
    
    var myStack = Stack()
    
    init(){
        display="0"
    }
    
    func evaluate(value: String){
        op = String(value)
        if(op=="+")
        {
            op = "+"
            myStack.push(String(num1))
            myStack.push(op)
            sum = true
        }
        if(op=="-")
        {
            op = "-"
            myStack.push(String(num1))
            myStack.push(op)
            minus = true
        }
        if(op=="*")
        {
            op = "*"
            myStack.push(String(num1))
            myStack.push(op)
            mul = true
        }
        if(op=="/")
        {
            op = "/"
            myStack.push(String(num1))
            myStack.push(op)
            div = true
        }
        firstNum = false
        if(op=="=" && firstNum==false)
        {
            myStack.push(String(num2))
            equals()
        }
        display = String(0)
        print(myStack)
    }
    
    func add(first: Double, second:Double, third: String) -> Double{
        num3 = num1 + num2
        myStack.push(String(num3))
        sum = false
        num1=num3
        display = String(myStack.peek()!)
        return Double(display)!
    }
    
    func subtract(first: Double, second:Double, third: String) -> Double{
        num3 = num1 - num2
        myStack.push(String(num3))
        minus = false
        num1=num3
        display = String(myStack.peek()!)
        return Double(display)!
    }
    
    func multiply(first: Double, second:Double, third: String) -> Double{
        num3 = num1 * num2
        myStack.push(String(num3))
        mul = false
        num1=num3
        display = String(myStack.peek()!)
        return Double(display)!
    }
    
    func divide(first: Double, second:Double, third: String) -> Double{
        num3 = num1 / num2
        div = false
        if(num2 == 0)
        {
            display  = "Undefined"
            return 0
        }
        else
        {
            myStack.push(String(num3))
            num1=num3
            display = String(myStack.peek()!)
            return Double(display)!
        }
    }
    
    func equals()
    {
        if(sum==true)
        {
            add(first: num1, second: num2, third: display)
        }
        if(minus==true)
        {
            subtract(first: num1, second: num2, third: display)
        }
        if(mul==true)
        {
            multiply(first: num1, second: num2, third: display)
        }
        if(div==true)
        {
            divide(first: num1, second: num2, third: display)
        }
    }
    
    func appendDisplay(value:String){
        display += value
        if(firstNum==true)
        {
            num1 = Double(display)!
        }
        if(firstNum==false && finished==false)
        {
            num2 = Double(display)!
        }
        if(finished==true)
        {
            num3 = Double(display)!
            finished = false
        }
    }
    
    func clear(value: String)
    {
        myStack.pop()
        myStack.pop()
        myStack.pop()
        myStack.pop()
        myStack.pop()
        firstNum = true
    }
    
    func negate(value: String)
    {
        if(firstNum==true)
        {
            num1=num1 * -1
            print(myStack)
        }
        if(firstNum==false)
        {
            num2=num2 * -1
        }
    }
    
    func squareroot(value: String)
    {
        if(firstNum==true)
        {
            num1=sqrt(num1)
            print(myStack)
        }
        if(firstNum==false)
        {
            num2=sqrt(num2)
        }
    }
    
    func percent(value: String)
    {
        if(firstNum==true)
        {
            num1=num1/100
            print(myStack)
        }
        if(firstNum==false)
        {
            num2=num2/100
        }
    }
}
