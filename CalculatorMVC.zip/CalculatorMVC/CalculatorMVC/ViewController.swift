//
//  ViewController.swift
//  CalculatorMVC
//
//  Created by NICHOLAS SENA on 3/4/19.
//  Copyright © 2019 NICHOLAS SENA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBOutlet weak var lblDisplay: UILabel!
    
    var myBrain: Brain = Brain();
    var forNegation: Bool = false
    var forSquare: Bool = false
    
    @IBAction func btnNumberInput(_ sender: UIButton) {
        guard let strIn = sender.currentTitle else{
            return
        }
        myBrain.appendDisplay(value: strIn)
        lblDisplay.text = myBrain.display
    }
    
    @IBAction func btnOperator(_ sender: UIButton) {
        guard let strIn = sender.currentTitle else{
            return
        }
        myBrain.evaluate(value: strIn)
        if(strIn != "=")
        {
            forNegation = true
        }
        if(strIn=="=")
        {
            lblDisplay.text = String(myBrain.num3)
            forNegation = false
        }
    }
    
    @IBAction func btnClear(_ sender: UIButton) {
        guard let strIn = sender.currentTitle else{
            return
        }
        
        lblDisplay.text = "0"
        myBrain.display = "0"
        myBrain.clear(value: strIn)
    }
    
    
    @IBAction func Negate(_ sender: UIButton) {
        guard let strIn = sender.currentTitle else{
            return
        }
        myBrain.negate(value: strIn)
        if(forNegation==false)
        {
            lblDisplay.text = String(myBrain.num1)
        }
        if(forNegation==true)
        {
            lblDisplay.text = String(myBrain.num2)
        }
    }
    
    @IBAction func squareRoot(_ sender: UIButton) {
        guard let strIn = sender.currentTitle else{
            return
        }
        myBrain.squareroot(value: strIn)
        if(forNegation==false)
        {
            lblDisplay.text = String(myBrain.num1)
        }
        if(forNegation==true)
        {
            lblDisplay.text = String(myBrain.num2)
        }
    }
    
    
    @IBAction func percentage(_ sender: UIButton) {
        guard let strIn = sender.currentTitle else{
            return
        }
        myBrain.percent(value: strIn)
        if(forNegation==false)
        {
            lblDisplay.text = String(myBrain.num1)
        }
        if(forNegation==true)
        {
            lblDisplay.text = String(myBrain.num2)
        }
    }
}

